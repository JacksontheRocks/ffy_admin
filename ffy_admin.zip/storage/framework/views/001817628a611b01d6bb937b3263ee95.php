

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Drivers</h1>
    <a href="<?php echo e(route('drivers.create')); ?>" class="btn btn-primary mb-3">Agregar Driver</a>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>NIF/CIF</th>
                <th>Dirección</th>
                <th>Código Postal</th>
                <th>Provincia</th>
                <th>Localidad</th>
                <th>Teléfono</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($driver->id); ?></td>
                    <td><?php echo e($driver->name); ?></td>
                    <td><?php echo e($driver->nif_cif); ?></td>
                    <td><?php echo e($driver->direccion); ?></td>
                    <td><?php echo e($driver->codigo_postal); ?></td>
                    <td><?php echo e($driver->provincia); ?></td>
                    <td><?php echo e($driver->localidad); ?></td>
                    <td><?php echo e($driver->telefono); ?></td>
                    <td>
                        <a href="<?php echo e(route('drivers.show', $driver->id)); ?>" class="btn btn-info">Ver</a>
                        <a href="<?php echo e(route('drivers.edit', $driver->id)); ?>" class="btn btn-warning">Editar</a>
                        <form action="<?php echo e(route('drivers.destroy', $driver->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ffy_admin\resources\views/drivers/index.blade.php ENDPATH**/ ?>