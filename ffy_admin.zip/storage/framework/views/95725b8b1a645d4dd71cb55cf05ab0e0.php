<?php $__env->startSection('content'); ?>
<div class="flex-center position-ref full-height">
    <div class="content">
        <div class="title m-b-md">
            <?php echo e(config('app.name', 'Laravel')); ?>

        </div>

        <div class="menu">
            <div class="menu-item">
                <a href="<?php echo e(route('drivers.index')); ?>">Conductores</a>
            </div>
            <div class="menu-item">
                <a href="<?php echo e(route('owners.index')); ?>">Propietarios</a>
            </div>
            <div class="menu-item">
                <a href="<?php echo e(route('vehicles.index')); ?>">Vehículos</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ffy_admin\resources\views/welcome.blade.php ENDPATH**/ ?>