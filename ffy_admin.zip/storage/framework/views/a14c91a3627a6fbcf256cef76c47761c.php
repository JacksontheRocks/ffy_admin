<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Índice de Vehículos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" defer></script>
</head>
<body>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container mt-5">
        <h1>Índice de Vehículos</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Matrícula</th>
                    <th>Tipo</th>
                    <th>Conductores Asignados</th>
                    <th>Propietarios Asignados</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($vehicle->id); ?></td>
                        <td><?php echo e($vehicle->marca); ?></td>
                        <td><?php echo e($vehicle->model); ?></td>
                        <td><?php echo e($vehicle->matricula); ?></td>
                        <td><?php echo e($vehicle->type); ?></td>
                        <td>
                            <?php if($vehicle->drivers->isEmpty()): ?>
                                No tiene conductores asignados
                            <?php else: ?>
                                <ul>
                                    <?php $__currentLoopData = $vehicle->drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($driver->name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($vehicle->owners->isEmpty()): ?>
                                No tiene propietarios asignados
                            <?php else: ?>
                                <ul>
                                    <?php $__currentLoopData = $vehicle->owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($owner->name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('vehicles.edit', $vehicle)); ?>" class="btn btn-primary">Editar</a>
                            <form action="<?php echo e(route('vehicles.destroy', $vehicle)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Eliminar</button>
                            </form>
                            <a href="<?php echo e(route('vehicles.assign_driver_form', $vehicle)); ?>" class="btn btn-secondary">Asignar Conductor</a>
                            <a href="<?php echo e(route('vehicles.assign_owner_form', $vehicle)); ?>" class="btn btn-secondary">Asignar Propietario</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('vehicles.create')); ?>" class="btn btn-success">Crear Vehículo</a>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ffy_admin\resources\views/vehicles/index.blade.php ENDPATH**/ ?>